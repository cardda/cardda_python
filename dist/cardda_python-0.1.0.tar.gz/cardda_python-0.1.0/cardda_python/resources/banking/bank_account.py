from cardda_python.resources.base_resource import BaseResource


class BankAccount(BaseResource):
    name = 'bank_accounts'