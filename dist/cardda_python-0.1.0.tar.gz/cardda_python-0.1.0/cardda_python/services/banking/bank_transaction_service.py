from cardda_python.services.base_service import BaseService
from cardda_python.resources.banking.bank_transaction import BankTransaction

class BankTransactionService(BaseService):
    resource = BankTransaction
    methods = ["all", "find", "save", "create"]

    def enqueue(self, obj: BankTransaction):
        obj.raw_data = self._client._request("POST", f"/{obj.id}/enqueue")
        return self

    def dequeue(self, obj: BankTransaction):
        obj.raw_data = self._client._request("PATCH", f"/{obj.id}/dequeue")
        return obj