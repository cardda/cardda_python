from cardda_python.services.base_service import BaseService
from cardda_python.resources.banking.bank_payroll import BankPayroll

class BankPayrollService(BaseService):
    resource = BankPayroll
    methods = ["all", "find", "save", "create", "delete"]

    def enroll(self, obj: BankPayroll, **data):
        response = self._client._request("POST", f"/{obj.id}/enroll", data=data)
        obj.raw_data = response
        return obj

    def remove(self, obj: BankPayroll, **data):
        response = self._client._request("PATCH", f"/{obj.id}/remove", data=data)
        obj.raw_data = response
        return obj
    
    def authorize(self, obj: BankPayroll, **data):
        response = self._client._request("POST", f"/{obj.id}/authorize", data=data)
        obj.raw_data = response
        return obj
    
    def authorize_recipients(self, obj: BankPayroll, **data):
        response = self._client._request("POST", f"/{obj.id}/validate", data=data)
        obj.raw_data = response
        return obj  