from cardda_python.resources.base_resource import BaseResource


class BankKey(BaseResource):
    name = 'bank_keys'