from abc import ABC, abstractclassmethod
from typing import Any, Dict
from cardda_python.http_client import HttpClient


class BaseResource(ABC):
    def __init__(self, data) -> None:
        self.raw_data: Dict[Any, Any] = data
    
    @property
    def id(self):
        return self.raw_data["id"]
    
    @property
    @abstractclassmethod
    def name() -> str:
        pass

    def as_json(self):
        return {k: v for k, v in self.raw_data.items() if k not in self.ignored_attributes and not self.is_nested_obj(k)}

    @property
    def ignored_attributes(cls):
        return ["updated_at", "created_at"]
    
    def is_nested_obj(self, key) -> bool:
        if type(self.raw_data.get(key)) in [int, str, bool] or (
            self.raw_data.get(key) == None and key in self.raw_data.keys()):
            return False
        return True