from http_client import HttpClient
from cardda_python.services.banking.bank_transaction_service import BankTransactionService
from cardda_python.services.banking.bank_account_service import BankAccountService
from cardda_python.services.banking.bank_key_service import BankKeyService
from cardda_python.services.banking.bank_payroll_service import BankPayrollService
from cardda_python.services.banking.bank_recipient_service import BankRecipientService

class BankingService:
    path_prefix = "banking"

    def __init__(self, client: HttpClient):
        self._client = client.extend(
            base_url= f"{client.base_url}/{self.path_prefix}"
        )
    
    @property
    def accounts(self):
        return BankAccountService(self._client)
    
    @property
    def recipients(self):
        return BankRecipientService(self._client)
    
    @property
    def transactions(self):
        return BankTransactionService(self._client)
    
    @property
    def payrolls(self):
        return BankPayrollService(self._client)
    
    @property
    def keys(self):
        return BankKeyService(self._client)