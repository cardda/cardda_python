API_BASE_URL = "https://api.cardda.com"
API_VERSION = "v1"
BANKING_PREFIX = "/banking"