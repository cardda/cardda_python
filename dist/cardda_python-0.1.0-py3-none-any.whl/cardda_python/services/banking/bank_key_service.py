from cardda_python.services.base_service import BaseService
from cardda_python.resources.banking.bank_key import BankKey

class BankKeyService(BaseService):
    resource = BankKey
    methods = ["all", "find", "save", "create"]