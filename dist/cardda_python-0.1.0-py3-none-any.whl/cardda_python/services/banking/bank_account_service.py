from cardda_python.services.base_service import BaseService
from cardda_python.resources.banking.bank_account import BankAccount

class BankAccountService(BaseService):
    resource = BankAccount
    methods = ["all", "find"]

    def preauthorize_transactions(self, obj: BankAccount, **data):
        obj.raw_data = self._client._request("POST", f"/{obj.id}/preauthorize", data=data)
        return obj
        
    def authorize_transactions(self, obj: BankAccount, **data):
        obj.raw_data = self._client._request("POST", f"/{obj.id}/authorize", data=data)
        return obj
        
    def authorize_payrolls(self, obj: BankAccount, **data):
        obj.raw_data = self._client._request("POST", f"/{obj.id}/authorize_payrolls", data=data)
        return obj
    
    def dequeue_transactions(self, obj: BankAccount, **data):
        obj.raw_data = self._client._request("POST", f"/{obj.id}/dequeue_all", data=data)
        return obj
    
    def sync_transactions(self, obj: BankAccount, **data):
        obj.raw_data = self._client._request("POST", f"/{obj.id}/sync_transactions", data=data)
        return obj

    def sync_recipients(self, obj: BankAccount, **data):
        obj.raw_data = self._client._request("POST", f"/{obj.id}/sync_recipients", data=data)
        return obj