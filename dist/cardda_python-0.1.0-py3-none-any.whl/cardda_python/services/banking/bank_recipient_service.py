from cardda_python.services.base_service import BaseService
from cardda_python.resources.banking.bank_recipient import BankRecipient

class BankRecipientService(BaseService):
    resource = BankRecipient
    methods = ["all", "find", "save", "create"]

    def authorize(self, **data):
        response = self._client._request("POST", "/authorize", data=data)
        self.raw_data = response
        return response